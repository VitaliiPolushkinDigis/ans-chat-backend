import { User } from './User';
import { Conversation } from './Conversation';
export declare class Message {
    id: number;
    content: string;
    createdAt: Date;
    author: User;
    conversation: Conversation;
}
