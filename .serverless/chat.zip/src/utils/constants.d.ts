export declare enum Routes {
    AUTH = "auth",
    USERS = "users",
    CONVERSATIONS = "conversations",
    MESSAGES = "messages"
}
export declare enum Services {
    AUTH = "AUTH_SERVICES",
    USERS = "USERS_SERVICES",
    CONVERSATIONS = "CONVERSATIONS",
    MESSAGES = "MESSAGES_SERVICE"
}
