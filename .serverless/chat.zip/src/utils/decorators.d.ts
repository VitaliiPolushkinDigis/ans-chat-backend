export declare const AuthUser: (...dataOrPipes: unknown[]) => ParameterDecorator;
