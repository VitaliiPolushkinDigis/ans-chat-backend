export declare class CreateMessageDto {
    content: string;
    conversationId: number;
}
