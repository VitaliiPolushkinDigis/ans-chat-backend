export declare class CreateConversationDto {
    recipientId: number;
    message: string;
}
