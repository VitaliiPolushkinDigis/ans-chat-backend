export declare class ConversationsModule {
}
