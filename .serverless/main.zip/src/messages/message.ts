import { CreateMessageParams } from './../utils/types';
import { Message } from 'src/utils/typeorm';

export interface IMessageService {
  createMessage(params: CreateMessageParams): Promise<Message>;
  getMessagesByConversationId(conversationId: number): Promise<Message[]>;
}
